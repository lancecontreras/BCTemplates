﻿namespace $safeprojectname$
{
  public sealed class BrokeredComponent1
{
  public string GetValue()
  {
    return "Hello .NET world";
  }
}
}
